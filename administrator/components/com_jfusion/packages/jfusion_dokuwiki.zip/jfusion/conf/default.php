<?php
/**
 * Default settings for the jfusion plugin
 *
 * @author JFusion Team <webmaster@jfusion.org>
 */

//$conf['jfusion']['cookie_path']      = '/';
//$conf['jfusion']['cookie_domain']    = '.mysite.com';
//$conf['jfusion']['joomla']           = 1;  //enables dual login from Dokuwiki to Joomla
//$conf['jfusion']['joomla_basepath']  = '/path/to/joomla/root'; //no ending slash; needed if joomla = 1
//$conf['jfusion']['jfusion_plugin_name'] = 'dokuwiki'; //the name of the dokuwiki plugin in JFusion; needed if joomla = 1